"""Loopback range server. Count successful body writes, not client consumption."""
import json
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit


class RangeServer(ThreadingHTTPServer):
    daemon_threads = False
    allow_reuse_address = True

    def __init__(self, root, log_path):
        super().__init__(("127.0.0.1", 0), Handler)
        self.root = Path(root)
        self.log_path = Path(log_path)
        self.manifest = json.loads((self.root / "manifest.json").read_text())
        self.label = "unassigned"
        self.log_lock = threading.Lock()
        self.active = 0
        self.active_lock = threading.Lock()

    def log_event(self, event):
        with self.log_lock:
            with self.log_path.open("a") as f:
                f.write(json.dumps(event, sort_keys=True) + "\n")


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass

    def do_HEAD(self):
        self.serve(False)

    def do_GET(self):
        self.serve(True)

    def serve(self, body):
        s = self.server
        event = {"label": s.label, "method": self.command, "path": urlsplit(self.path).path,
                 "range": self.headers.get("Range"), "body_written": 0, "aborted": False, "started_ns": time.time_ns()}
        with s.active_lock:
            s.active += 1
        try:
            name = event["path"].rsplit("/", 1)[-1]
            if name not in s.manifest["files"]:
                self.send_error(404)
                event["status"] = 404
                return
            path = s.root / name
            size = path.stat().st_size
            begin, end, status = 0, size - 1, 200
            if event["range"]:
                m = re.fullmatch(r"bytes=(\d*)-(\d*)", event["range"])
                if not m:
                    self.send_error(416)
                    event["status"] = 416
                    return
                if m[1]:
                    begin = int(m[1])
                    end = min(end, int(m[2])) if m[2] else end
                else:
                    begin = max(0, size - int(m[2]))
                if begin > end or begin >= size:
                    self.send_error(416)
                    event["status"] = 416
                    return
                status = 206
            event.update(status=status, requested_bytes=end - begin + 1 if body else 0, file_bytes=size)
            self.send_response(status)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(end - begin + 1))
            self.send_header("ETag", '"' + s.manifest["files"][name]["sha256"] + '"')
            self.send_header("Last-Modified", "Thu, 01 Jan 2026 00:00:00 GMT")
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Connection", "close")
            if status == 206:
                self.send_header("Content-Range", f"bytes {begin}-{end}/{size}")
            self.end_headers()
            self.close_connection = True
            if body:
                with path.open("rb") as f:
                    f.seek(begin)
                    remaining = end - begin + 1
                    while remaining:
                        chunk = f.read(min(64 * 1024, remaining))
                        self.wfile.write(chunk)
                        event["body_written"] += len(chunk)
                        remaining -= len(chunk)
        except (BrokenPipeError, ConnectionResetError):
            event["aborted"] = True
        finally:
            event["finished_ns"] = time.time_ns()
            s.log_event(event)
            with s.active_lock:
                s.active -= 1
