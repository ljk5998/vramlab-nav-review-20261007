"""Deterministic public-domain synthetic rows; no source data from user caches."""
import base64
import csv
import hashlib
import json
from pathlib import Path

ROWS = 200_000
PREFIX_ROWS = 1_000


def payload(index):
    return base64.b64encode(hashlib.shake_256(f"vramlab-streaming-row:{index}".encode()).digest(288)).decode()


def row_bytes(row):
    return json.dumps({"id": int(row["id"]), "payload": row["payload"]}, sort_keys=True, separators=(",", ":")).encode() + b"\n"


def sha_file(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def generate(root):
    import pyarrow as pa
    import pyarrow.parquet as pq
    root = Path(root)
    root.mkdir(parents=True, exist_ok=False)
    csv_path, parquet_path = root / "rows.csv", root / "rows.parquet"
    full, prefix = hashlib.sha256(), hashlib.sha256()
    schema = pa.schema([("id", pa.int64()), ("payload", pa.string())])
    with csv_path.open("w", newline="", encoding="utf-8") as cf, pq.ParquetWriter(parquet_path, schema, compression="zstd", use_dictionary=False) as pw:
        cw = csv.DictWriter(cf, fieldnames=["id", "payload"], lineterminator="\n")
        cw.writeheader()
        for start in range(0, ROWS, 10_000):
            batch = [{"id": i, "payload": payload(i)} for i in range(start, start + 10_000)]
            cw.writerows(batch)
            pw.write_table(pa.Table.from_pylist(batch, schema=schema), row_group_size=10_000)
            for row in batch:
                packed = row_bytes(row)
                full.update(packed)
                if row["id"] < PREFIX_ROWS:
                    prefix.update(packed)
    manifest = {"rows": ROWS, "prefix_rows": PREFIX_ROWS, "payload_chars": 384, "row_group_size": 10_000,
                "digest_all": full.hexdigest(), "digest_prefix": prefix.hexdigest(),
                "files": {p.name: {"bytes": p.stat().st_size, "sha256": sha_file(p)} for p in (csv_path, parquet_path)}}
    (root / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


if __name__ == "__main__":
    import sys
    print(json.dumps(generate(sys.argv[1]), indent=2))
