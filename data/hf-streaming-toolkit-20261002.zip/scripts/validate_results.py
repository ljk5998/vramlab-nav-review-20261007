"""Independent decoded-input/output audit. Does not import the measurement code."""
import argparse
import base64
import csv
import hashlib
import json
import statistics
from collections import defaultdict
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq


def hashed(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def update(h, record):
    h.update(json.dumps(record, separators=(",", ":"), sort_keys=True, ensure_ascii=False).encode("utf-8") + b"\n")


parser = argparse.ArgumentParser()
parser.add_argument("--run", required=True)
parser.add_argument("--fixture", required=True)
parser.add_argument("--output", required=True)
args = parser.parse_args()
run, fixture = Path(args.run), Path(args.fixture)
manifest = json.loads((run / "run-manifest.json").read_text())
source = json.loads((fixture / "manifest.json").read_text())
issues, checks = [], 0


def check(condition, message):
    global checks
    checks += 1
    if not condition:
        issues.append(message)


check(manifest["fixture"] == source, "input manifest changed")
for name, meta in source["files"].items():
    check((fixture / name).stat().st_size == meta["bytes"], f"source byte count {name}")
    check(hashed(fixture / name) == meta["sha256"], f"source sha {name}")
csv_all, csv_prefix, csv_count = hashlib.sha256(), hashlib.sha256(), 0
with (fixture / "rows.csv").open(newline="") as f:
    for record in csv.DictReader(f):
        row = {"id": int(record["id"]), "payload": record["payload"]}
        check(row["id"] == csv_count, f"CSV ordered id {csv_count}")
        expected = base64.b64encode(hashlib.shake_256(("vramlab-streaming-row:" + str(csv_count)).encode()).digest(288)).decode()
        check(row["payload"] == expected, f"CSV generated payload {csv_count}")
        update(csv_all, row)
        if csv_count < source["prefix_rows"]:
            update(csv_prefix, row)
        csv_count += 1
check(csv_count == source["rows"], "CSV row count")
check(csv_all.hexdigest() == source["digest_all"], "CSV full digest")
check(csv_prefix.hexdigest() == source["digest_prefix"], "CSV prefix digest")
parquet_all, parquet_count = hashlib.sha256(), 0
for batch in pq.ParquetFile(fixture / "rows.parquet").iter_batches(batch_size=10_000):
    for row in batch.to_pylist():
        update(parquet_all, row)
        parquet_count += 1
check(parquet_count == csv_count and parquet_all.hexdigest() == csv_all.hexdigest(), "same logical Parquet and CSV rows")

hub_csvs = list(run.glob("hub-csv-normal-*/root/hf/hub/datasets--lhoestq--demo1/snapshots/*/data/train.csv"))
check(bool(hub_csvs), "retained original pinned Hub CSV")
hub_digest = hashlib.sha256()
hub_count = 0
if hub_csvs:
    with hub_csvs[0].open(newline="") as f:
        for record in csv.DictReader(f):
            record["star"] = int(record["star"])
            record["version_id"] = int(record["version_id"])
            update(hub_digest, record)
            hub_count += 1
    check(hub_count == 5, "actual Hub CSV five rows")
    for path in hub_csvs:
        check(path.parent.parent.name == "87ecf163bedca9d80598b528940a9c4f99e14c11", "Hub revision path")
        check(hashed(path) == hashed(hub_csvs[0]), "consistent pinned Hub source bytes")

rows = []
groups = defaultdict(list)
all_requests = [json.loads(line) for line in (run / "http-requests.jsonl").read_text().splitlines()]
for pair, spec in manifest["specs"]:
    case = run / pair
    pair_records = []
    for state in ("empty", "reused"):
        target = case / state
        required = ["wrapper.json", "probe.json", "before.json", "after.json", "cleanup.json", "resource-exit.json", "stdout.txt", "stderr.txt"]
        for filename in required:
            check((target / filename).is_file(), f"missing {pair}/{state}/{filename}")
        if any(not (target / f).is_file() for f in required):
            continue
        wrapper = json.loads((target / "wrapper.json").read_text())
        probe = json.loads((target / "probe.json").read_text())
        before = json.loads((target / "before.json").read_text())
        after = json.loads((target / "after.json").read_text())
        rss = json.loads((target / "resource-exit.json").read_text())["peak_rss_kib"]
        check(wrapper["status"] == "EXECUTED" and wrapper["exit_code"] == 0, f"process completion {pair}/{state}")
        check(wrapper["spec"] == spec and wrapper["pair"] == pair and wrapper["cache_state"] == state, f"condition identity {pair}/{state}")
        check(wrapper["probe_sha256"] == manifest["scripts"]["probe.py"], f"frozen probe {pair}/{state}")
        check(probe["actual_rows"] == spec["rows"], f"returned row count {pair}/{state}")
        expected_digest = hub_digest.hexdigest() if spec["study"] == "hub" else (csv_prefix.hexdigest() if spec["rows"] == source["prefix_rows"] else csv_all.hexdigest())
        check(probe["ordered_sha256"] == expected_digest, f"decoded row digest {pair}/{state}")
        check(probe["mode"] == spec["mode"] and probe["format"] == spec["format"], f"probe condition {pair}/{state}")
        check(probe["dataset_type"] == ("Dataset" if spec["mode"] == "normal" else "IterableDataset"), f"object type {pair}/{state}")
        check(0 <= probe["load_s"] <= probe["first_row_s"] <= probe["work_s"] <= wrapper["process_wall_s"], f"timing order {pair}/{state}")
        check(rss >= probe["peak_rss_kib_at_result"] and rss < 3 * 1024 * 1024, f"completed process peak RSS {pair}/{state}")
        wanted = [r for r in all_requests if r["label"] == f"{pair}/{state}"]
        check(wrapper["requests"] == wanted, f"server request log equality {pair}/{state}")
        body_written = sum(r["body_written"] for r in wanted)
        check(body_written == wrapper["server_body_written"], f"server body-write sum {pair}/{state}")
        for request in wanted:
            check(request["status"] in (200, 206), f"HTTP status {pair}/{state}")
            check(0 <= request["body_written"] <= request["requested_bytes"], f"request byte bounds {pair}/{state}")
            if request["method"] == "GET" and not request["aborted"]:
                check(request["body_written"] == request["requested_bytes"], f"complete response exact bytes {pair}/{state}")
        if state == "empty":
            check(not before["entries"], f"empty initial application state {pair}")
        else:
            previous = json.loads((case / "empty" / "after.json").read_text())
            check(before == previous, f"exact reused baseline {pair}")
        for entry in after["entries"]:
            path = case / "root" / entry["path"]
            if entry["type"] == "file":
                check(path.stat().st_size == entry["bytes"], f"retained file bytes {pair}/{entry['path']}")
                check(hashed(path) == entry["sha256"], f"retained file hash {pair}/{entry['path']}")
        arrow_entries = [r for r in after["entries"] if r["type"] == "file" and r["path"].endswith(".arrow")]
        if spec["mode"] == "normal":
            check(len(arrow_entries) == 1, f"one materialized Arrow file {pair}/{state}")
        else:
            check(not arrow_entries, f"no prepared Arrow in tested stream {pair}/{state}")
        row = {"pair": pair, "study": spec["study"], "format": spec["format"], "mode": spec["mode"], "requested_rows": spec["rows"], "repeat": spec["repeat"],
               "cache_state": state, "actual_rows": probe["actual_rows"], "ordered_sha256": probe["ordered_sha256"], "first_row_s": probe["first_row_s"],
               "load_s": probe["load_s"], "work_s": probe["work_s"], "process_wall_s": wrapper["process_wall_s"], "peak_rss_kib": rss,
               "cache_bytes": after["regular_bytes_unique_inodes"], "cache_allocated_bytes": after["allocated_bytes_unique_inodes"],
               "server_body_written": body_written, "http_requests": len(wanted), "http_aborted": sum(r["aborted"] for r in wanted),
               "completed_get_body_bytes": sum(r["body_written"] for r in wanted if r["method"] == "GET" and not r["aborted"]),
               "completed_range_body_bytes": sum(r["body_written"] for r in wanted if r["method"] == "GET" and r["status"] == 206 and not r["aborted"]),
               "aborted_get_body_written": sum(r["body_written"] for r in wanted if r["method"] == "GET" and r["aborted"]),
               "versions": probe["versions"], "finished_utc": wrapper["finished_utc"]}
        rows.append(row)
        pair_records.append((state, after))
        groups[(spec["study"], spec["format"], spec["mode"], spec["rows"], state)].append(row)
    # Independently decode the actual materialized Arrow, once per cache pair.
    if spec["mode"] == "normal" and pair_records:
        for entry in pair_records[-1][1]["entries"]:
            if entry["type"] != "file" or not entry["path"].endswith(".arrow"):
                continue
            arrow_digest, arrow_count = hashlib.sha256(), 0
            with pa.memory_map(str(case / "root" / entry["path"]), "r") as mapped:
                for batch in pa.ipc.open_stream(mapped):
                    for record in batch.to_pylist():
                        update(arrow_digest, record)
                        arrow_count += 1
            expected_count = hub_count if spec["study"] == "hub" else source["rows"]
            expected = hub_digest.hexdigest() if spec["study"] == "hub" else csv_all.hexdigest()
            check(arrow_count == expected_count and arrow_digest.hexdigest() == expected, f"independently decoded complete Arrow {pair}")

check(len(rows) == len(manifest["specs"]) * 2, "complete declared cohort")
summary = []
for key, data in sorted(groups.items()):
    item = {"study": key[0], "format": key[1], "mode": key[2], "requested_rows": key[3], "cache_state": key[4], "n": len(data)}
    for field in ("cache_bytes", "cache_allocated_bytes", "server_body_written", "completed_get_body_bytes", "completed_range_body_bytes", "aborted_get_body_written", "http_requests", "http_aborted", "first_row_s", "work_s", "process_wall_s", "peak_rss_kib"):
        values = [r[field] for r in data]
        item[field] = {"median": statistics.median(values), "min": min(values), "max": max(values)}
    summary.append(item)
report = {"status": "PASS" if not issues else "FAIL", "checks": checks, "issues": issues, "cases": len(rows), "rows": rows, "groups": summary,
          "fixture": source, "hub_source_sha256": hashed(hub_csvs[0]) if hub_csvs else None,
          "run_manifest_sha256": hashed(run / "run-manifest.json"), "limitations": ["server metric counts successful body writes, not client-consumed bytes", "loopback timings are not WAN performance", "end-of-process file footprint is not peak temporary space or Windows VHDX allocation"]}
Path(args.output).write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": report["status"], "checks": checks, "cases": len(rows), "issues": issues[:15]}, indent=2), flush=True)
raise SystemExit(bool(issues))
