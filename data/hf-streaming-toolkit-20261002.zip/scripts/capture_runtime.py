import hashlib
import importlib.metadata
import json
import platform
import sys
from pathlib import Path


def file_sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


records = []
for dist in sorted(importlib.metadata.distributions(), key=lambda d: d.metadata["Name"].lower()):
    files = []
    for item in sorted(dist.files or [], key=str):
        path = Path(dist.locate_file(item)).resolve()
        if path.is_file() and path.suffix != ".pyc":
            files.append({"path": str(item), "bytes": path.stat().st_size, "sha256": file_sha(path)})
    records.append({"name": dist.metadata["Name"], "version": dist.version, "files": files})
manifest = {"python": sys.version, "executable": sys.executable, "executable_sha256": file_sha(Path(sys.executable)),
            "platform": platform.platform(), "distributions": records}
Path(sys.argv[1]).write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"packages": len(records), "files": sum(len(p["files"]) for p in records), "output": sys.argv[1]}))
