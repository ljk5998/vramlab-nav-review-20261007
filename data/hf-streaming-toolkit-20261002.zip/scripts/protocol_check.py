import json
import sys
import tempfile
import threading
import urllib.request
from pathlib import Path

from range_server import RangeServer

fixture = Path(sys.argv[1])
target = Path(sys.argv[2])
assert not target.exists()
server = RangeServer(fixture, target.with_suffix(".requests.jsonl"))
thread = threading.Thread(target=server.serve_forever)
thread.start()
checks = []
try:
    for filename in ("rows.csv", "rows.parquet"):
        source = (fixture / filename).read_bytes()
        url = f"http://127.0.0.1:{server.server_port}/{filename}"
        with urllib.request.urlopen(urllib.request.Request(url, method="HEAD")) as response:
            assert response.status == 200 and int(response.headers["Content-Length"]) == len(source) and response.read() == b""
            checks.append({"file": filename, "check": "HEAD_size_no_body"})
        for spec, expected in (("bytes=0-999", source[:1000]), ("bytes=-1024", source[-1024:]), (f"bytes={len(source)-99}-", source[-99:])):
            with urllib.request.urlopen(urllib.request.Request(url, headers={"Range": spec})) as response:
                received = response.read()
                assert response.status == 206 and received == expected and int(response.headers["Content-Length"]) == len(expected)
                checks.append({"file": filename, "check": spec, "body_bytes": len(received)})
finally:
    server.shutdown()
    thread.join()
    server.server_close()
requests = [json.loads(line) for line in target.with_suffix(".requests.jsonl").read_text().splitlines()]
assert len(requests) == 8 and sum(r["body_written"] for r in requests) == 2 * (1000 + 1024 + 99)
assert not any(r["aborted"] for r in requests)
target.write_text(json.dumps({"status": "PASS", "checks": checks, "body_write_sum": sum(r["body_written"] for r in requests)}, indent=2) + "\n")
print(target.read_text())
