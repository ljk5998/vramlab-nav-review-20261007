"""Run one real load and bounded iteration in an isolated fresh process."""
import argparse
import atexit
import gc
import hashlib
import importlib.metadata
import json
import os
import resource
import sys
import time
from pathlib import Path

from fixture import row_bytes

parser = argparse.ArgumentParser()
parser.add_argument("--study", choices=("hub", "http"), required=True)
parser.add_argument("--format", choices=("csv", "parquet"), default="csv")
parser.add_argument("--mode", choices=("normal", "stream"), required=True)
parser.add_argument("--rows", type=int, required=True)
parser.add_argument("--url")
parser.add_argument("--result", required=True)
args = parser.parse_args()


def exit_resource():
    Path(args.result).with_name("resource-exit.json").write_text(json.dumps({
        "peak_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "captured_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}) + "\n")


atexit.register(exit_resource)

from datasets import load_dataset

assert not Path(os.environ["HF_HOME"], "token").exists()
started = time.perf_counter_ns()
if args.study == "hub":
    dataset = load_dataset("lhoestq/demo1", revision="87ecf163bedca9d80598b528940a9c4f99e14c11",
                           data_files={"train": "data/train.csv"}, split="train", streaming=args.mode == "stream", token=False)
else:
    dataset = load_dataset(args.format, data_files={"train": args.url}, split="train", streaming=args.mode == "stream")
loaded = time.perf_counter_ns()
iterator = iter(dataset)
digest = hashlib.sha256()
first = next(iterator)
first_ready = time.perf_counter_ns()


def packed(row):
    if args.study == "http":
        return row_bytes(row)
    return json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode() + b"\n"


digest.update(packed(first))
count = 1
last_id = first.get("id")
while count < args.rows:
    row = next(iterator)
    digest.update(packed(row))
    count += 1
    last_id = row.get("id")
finished = time.perf_counter_ns()
result = {"study": args.study, "format": args.format, "mode": args.mode, "requested_rows": args.rows,
          "actual_rows": count, "ordered_sha256": digest.hexdigest(), "last_id": last_id,
          "dataset_type": type(dataset).__name__, "load_s": (loaded - started) / 1e9,
          "first_row_s": (first_ready - started) / 1e9, "work_s": (finished - started) / 1e9,
          "iteration_after_load_s": (finished - loaded) / 1e9,
          "peak_rss_kib_at_result": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
          "python": sys.version, "versions": {p: importlib.metadata.version(p) for p in ("datasets", "huggingface_hub", "pyarrow", "fsspec", "pandas")},
          "cache_files": getattr(dataset, "cache_files", None), "first_row": first if args.study == "hub" else {"id": first["id"], "payload_chars": len(first["payload"])} }
Path(args.result).write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: result[k] for k in ("study", "format", "mode", "actual_rows", "ordered_sha256", "first_row_s", "work_s", "peak_rss_kib_at_result")}), flush=True)
cleanup_started = time.perf_counter()
if hasattr(iterator, "close"):
    iterator.close()
del iterator, dataset
gc.collect()
Path(args.result).with_name("cleanup.json").write_text(json.dumps({"iterator_closed": True, "cleanup_s": time.perf_counter() - cleanup_started}) + "\n")
