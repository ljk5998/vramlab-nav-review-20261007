"""Sequential fresh processes; immutable case output and retained failures."""
import argparse
import hashlib
import json
import os
import random
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

from fixture import ROWS, PREFIX_ROWS, sha_file
from range_server import RangeServer


def inventory(root):
    records, seen = [], set()
    total, allocated = 0, 0
    for p in sorted(root.rglob("*")):
        st = p.lstat()
        rec = {"path": p.relative_to(root).as_posix()}
        if p.is_symlink():
            rec.update(type="symlink", target=os.readlink(p))
        elif p.is_file():
            rec.update(type="file", bytes=st.st_size, allocated=st.st_blocks * 512, sha256=sha_file(p), mtime_ns=st.st_mtime_ns)
            if (st.st_dev, st.st_ino) not in seen:
                total += st.st_size
                allocated += st.st_blocks * 512
                seen.add((st.st_dev, st.st_ino))
        elif p.is_dir():
            continue
        else:
            raise RuntimeError(f"Unexpected file type: {p}")
        records.append(rec)
    return {"regular_bytes_unique_inodes": total, "allocated_bytes_unique_inodes": allocated, "entries": records}


def run_one(pair, state, spec, output, server):
    disk = os.statvfs("/mnt/c")
    if disk.f_bavail * disk.f_frsize < 50 * 1024 ** 3:
        raise RuntimeError("Host free-space stop threshold")
    used = sum(p.stat().st_size for p in output.rglob("*") if p.is_file() and not p.is_symlink())
    if used > 12 * 1024 ** 3:
        raise RuntimeError("Experiment file-footprint stop threshold")
    case_dir = output / pair
    root = case_dir / "root"
    if state == "empty":
        root.mkdir(parents=True, exist_ok=False)
        for name in ("home", "hf", "xdg", "tmp", "cwd"):
            (root / name).mkdir()
    target = case_dir / state
    target.mkdir(exist_ok=False)
    before = inventory(root)
    (target / "before.json").write_text(json.dumps(before, indent=2) + "\n")
    env = os.environ.copy()
    for key in tuple(env):
        if key.startswith(("HF_", "HUGGINGFACE_", "TRANSFORMERS_")):
            env.pop(key)
    env.update(HOME=str(root / "home"), HF_HOME=str(root / "hf"), XDG_CACHE_HOME=str(root / "xdg"), TMPDIR=str(root / "tmp"),
               HF_HUB_DISABLE_IMPLICIT_TOKEN="1", HF_HUB_DISABLE_TELEMETRY="1", HF_HUB_DISABLE_XET="1", PYTHONNOUSERSITE="1", TOKENIZERS_PARALLELISM="false")
    label = f"{pair}/{state}"
    server.label = label
    command = [sys.executable, str(Path(__file__).with_name("probe.py")), "--study", spec["study"], "--format", spec["format"],
               "--mode", spec["mode"], "--rows", str(spec["rows"]), "--result", str(target / "probe.json")]
    if spec["study"] == "http":
        command += ["--url", f"http://127.0.0.1:{server.server_port}/frozen/rows.{spec['format']}"]
    started = time.perf_counter()
    peak_rss_kib = 0
    with (target / "stdout.txt").open("w") as out, (target / "stderr.txt").open("w") as err:
        child = subprocess.Popen(command, cwd=root / "cwd", env=env, stdout=out, stderr=err, start_new_session=True)
        status = "EXECUTED"
        while child.poll() is None:
            try:
                for line in Path(f"/proc/{child.pid}/status").read_text().splitlines():
                    if line.startswith("VmHWM:"):
                        peak_rss_kib = max(peak_rss_kib, int(line.split()[1]))
            except FileNotFoundError:
                pass
            if time.perf_counter() - started > 180 or peak_rss_kib > 3 * 1024 * 1024:
                os.killpg(child.pid, signal.SIGKILL)
                status = "STOPPED_RESOURCE_LIMIT"
                break
            time.sleep(0.05)
        exit_code = child.wait()
    duration = time.perf_counter() - started
    deadline = time.monotonic() + 10
    while server.active:
        if time.monotonic() > deadline:
            raise RuntimeError("HTTP worker did not finish after child exit")
        time.sleep(0.02)
    requests = []
    if server.log_path.exists():
        requests = [json.loads(line) for line in server.log_path.read_text().splitlines() if json.loads(line)["label"] == label]
    after = inventory(root)
    (target / "after.json").write_text(json.dumps(after, indent=2) + "\n")
    record = {"pair": pair, "cache_state": state, "spec": spec, "status": status, "exit_code": exit_code,
              "process_wall_s": duration, "peak_rss_kib_sampled": peak_rss_kib,
              "requests": requests, "server_body_written": sum(r["body_written"] for r in requests),
              "probe_sha256": sha_file(Path(__file__).with_name("probe.py")),
              "command": command, "finished_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    (target / "wrapper.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"case": label, "exit": exit_code, "process_s": round(duration, 3), "cache_bytes": after["regular_bytes_unique_inodes"],
                      "server_body_written": record["server_body_written"]}), flush=True)
    if exit_code or status != "EXECUTED":
        raise RuntimeError(f"Case failed and retained at {target}")
    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fixture", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--scout", action="store_true")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    specs = []
    repetitions = 1 if args.scout else 3
    for repeat in range(1, repetitions + 1):
        for mode in ("normal", "stream"):
            specs.append((f"hub-csv-{mode}-r{repeat}", {"study": "hub", "format": "csv", "mode": mode, "rows": 5, "repeat": repeat}))
        for fmt in ("csv", "parquet"):
            for mode in ("normal", "stream"):
                for rows in ((PREFIX_ROWS,) if args.scout else (PREFIX_ROWS, ROWS)):
                    specs.append((f"http-{fmt}-{mode}-n{rows}-r{repeat}", {"study": "http", "format": fmt, "mode": mode, "rows": rows, "repeat": repeat}))
    random.Random(20261002).shuffle(specs)
    frozen = {"created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "specs": specs,
              "scripts": {p.name: sha_file(p) for p in sorted(Path(__file__).parent.glob("*.py"))},
              "fixture": json.loads((Path(args.fixture) / "manifest.json").read_text()),
              "design_sha256": sha_file(Path(__file__).parent.parent / "setup" / "WORK_PLAN.md"),
              "runtime_manifest_sha256": sha_file(Path(__file__).parent.parent / "setup" / "runtime-before.json"),
              "lock_sha256": sha_file(Path(__file__).parent.parent / "setup" / "requirements.lock"),
              "installed": subprocess.check_output([sys.executable, "-m", "pip", "freeze", "--all"], text=True).splitlines()}
    (output / "run-manifest.json").write_text(json.dumps(frozen, indent=2) + "\n")
    server = RangeServer(args.fixture, output / "http-requests.jsonl")
    worker = threading.Thread(target=server.serve_forever)
    worker.start()
    results = []
    try:
        for pair, spec in specs:
            results.append(run_one(pair, "empty", spec, output, server))
            results.append(run_one(pair, "reused", spec, output, server))
        (output / "execution-summary.json").write_text(json.dumps({"state": "EXECUTED", "cases": len(results), "results": results}, indent=2) + "\n")
    finally:
        server.shutdown()
        worker.join()
        server.server_close()


if __name__ == "__main__":
    main()
