HF Datasets streaming cache experiment on WSL2

CPU-only reproduction. Requires Python 3.12 and python3-venv. Use a fresh temporary lab.
Pinned datasets 5.0.1 / huggingface_hub 1.30.0 / pyarrow 25.0.1; complete Python lock included.
fixture.py generates identical 200,000 synthetic id/payload rows in CSV and Parquet.
run_matrix.py runs 60 fresh processes, 3 empty/reused pairs per condition. --scout runs only 12 prefix/small-Hub processes.
The loopback server logs HEAD/GET/ranges and body writes, including aborted responses.
Imports are outside load/first-row/work timers. Work includes JSON digesting. RSS summaries use ru_maxrss recorded in atexit after explicit cleanup and include imports.
Wrappers also retain separate 50 ms /proc VmHWM samples; do not treat callback RSS as measuring every remaining interpreter shutdown step.
Cache totals are final regular-file bytes (unique inodes) and allocated file blocks under the isolated HOME/HF_HOME/XDG/TMPDIR/cwd.
No OS page cache flush, internet throughput claim, VHDX reclaim, shuffle, GPU, training or transform benchmark.
Normal external URL download paths are not Hub blob paths. Hub measurement explicitly selects data/train.csv at the pinned revision.
The iterator is explicitly closed before interpreter shutdown, fixing the preparation timeout observed on this environment.
validate_results.py independently decodes fixture CSV, Parquet and cached Arrow and compares all row digests.
Outputs retain absolute paths from your own temporary lab; review/sanitize before sharing them.
The driver stops below 50 GiB host free space, above 12 GiB experiment files, after 180 seconds per child or above 3 GiB sampled RSS.
Expected permanent fixture sizes: CSV 78,288,901 bytes; Parquet 58,908,496 bytes.
Full-run cache/result allocation is a few GiB, with no automatic recursive removal.
