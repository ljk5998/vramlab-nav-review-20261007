Sanitized measured records. Primary cohort: 60 completed fresh processes.
scout-v1 includes an actual 180-second Parquet iterator shutdown timeout; never pooled with primary timings.
scout-v2 completed after explicit iterator closure.
Payload files, virtual environments, WSL images, credentials and host metadata are excluded.
Server log body_written counts bytes in successful server body writes; an aborted send may have uncounted partial writes.
completed_get_body_bytes excludes aborted responses, not all network activity.
RSS summaries use ru_maxrss captured in atexit after explicit cleanup; wrappers retain separate 50 ms VmHWM samples.
Paths/loopback port and Hub sample text are sanitized. ZIP MANIFEST hashes refer to these public bytes.
